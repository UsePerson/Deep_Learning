#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np


# In[8]:



class ActivationFunction:
    
    def __init__(self, types='Sigmoid'):
        
        self.func = self.Sigmoid
        self.dfunc = self.dSigmoid
        
        if types == 'Sigmoid':
            
            self.func = self.Sigmoid
            self.dfunc = self.dSigmoid
            
        elif types == 'Sign':
            
            pass
        
        
        
        
    def Sigmoid(self, x):
        
        return 1 / (1 + np.exp(-x))
    
    def dSigmoid(self, output):
        
        return np.multiply(output, (1 - output))
    
if __name__ == '__main__':
    
    myfunc = ActivationFunction('Sigmoid')
    
    


# In[7]:





# In[ ]:




